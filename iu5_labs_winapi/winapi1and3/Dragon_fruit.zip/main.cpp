#include "mainwindow.h"
#include <QApplication>

int main() {
    int argc = 0;
    char *argv[] = {};
    QApplication a(argc, argv);
    MainWindow w;
    w.show();

    return a.exec();
}
