#include "squads.h"

Squads::Squads() {

}
