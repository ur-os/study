#ifndef SQUADS_H
#define SQUADS_H

#include "glwidget.h"

class Squads {

public:
    Squads();
};

#endif // SQUADS_H
